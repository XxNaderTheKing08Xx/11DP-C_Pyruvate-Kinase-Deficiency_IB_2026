## 2. Gantt chart: task details

*Days are working days. Predecessors must be finished before a task starts. Each task has one owner; full names and roles are given in Section 1. Tasks 1.1 to 1.5 take place in sequence on 9 October: 1.1 creates the folders that the other four commits use.*

### Phase 0 — Project start-up (completed)

| ID | Task | Owner | Output | Dates | Evidence |
|---|---|---|---|---|---|
| 0.1 | Create the GitHub repository and write the README | Leo | Repository 11DP-C_Pyruvate-Kinase-Deficiency_IB_2026 | Thu 17 Sep | Commits of 17 Sep |
| 0.2 | Create the report file and the folder structure | Ettore | `report.md`, `figures/` | Thu 17 Sep | Commits of 17 Sep |
| 0.3 | Study the course instructions and the disease | All | Shared understanding of the task | Mon 21 Sep – Thu 8 Oct | Reported by the team |
| 0.4 | Team meeting 1 (after class) | All | Organization of the work | Mon 21 Sep | Reported by the team |
| 0.5 | Format the report file | Aarón | Formatted `report.md` | Mon 28 Sep | Commit of 28 Sep |
| 0.6 | Team meeting 2 (after class) | All | Organization of the work | Mon 28 Sep | Reported by the team |
| 0.7 | Team meeting 3 (after class) | All | Organization of the work | Mon 5 Oct | Reported by the team |
| 0.8 | Draft the project plan (introduction, objectives, Gantt chart, risks) | Ettore | Draft plan, sections PKD_1 to PKD_6 | Mon 5 Oct – Thu 8 Oct | Draft files |
| 0.9 | Team meeting 4 (after class): review of the draft plan; decision to submit it through GitHub rather than as a PDF | All | Agreed plan and submission format | Thu 8 Oct | Reported by the team |

### WP1 — Project management and GitHub

Fri 9 Oct – Tue 27 Oct (12 working days)

| ID | Task | Owner | Output | Days | Start | End | Predecessors | Accomplished when |
|---|---|---|---|---|---|---|---|---|
| 1.1 | Review and commit the introduction (PKD_1); create the folders `report/`, `status/`, `gantt/`, and `references/` | Ettore | Introduction and required folders in the repository | 1 | Fri 9 Oct | Fri 9 Oct | — | The four required folders exist and the introduction is committed by its reviewer. |
| 1.2 | Review and commit the overview and team section (PKD_2); submit the repository URL on Moodle | Aarón | PKD_2 committed; URL submitted | 1 | Fri 9 Oct | Fri 9 Oct | 1.1 | The URL is submitted on Moodle before 18:00 on 9 Oct. |
| 1.3 | Review and commit the Gantt chart (PKD_3) | Leo | PKD_3 committed | 1 | Fri 9 Oct | Fri 9 Oct | 1.1 | The chart renders on GitHub and its dates match PKD_4. |
| 1.4 | Review and commit the task details (PKD_4) | Pol | PKD_4 committed | 1 | Fri 9 Oct | Fri 9 Oct | 1.1 | Every task has an owner, output, duration, predecessor, and completion criterion. |
| 1.5 | Review and commit the risk analysis and references (PKD_5, PKD_6) | Bruno | PKD_5 and PKD_6 committed | 1 | Fri 9 Oct | Fri 9 Oct | 1.1 | Each risk has a score and a contingency plan; every citation has a reference. |
| 1.6 | Create the Project Status document | Ettore | `status/` document | 1 | Tue 13 Oct | Tue 13 Oct | 1.2 | It lists every task with owner, planned dates, real dates, status, and notes. |
| 1.7 | Weekly status update and team meeting (Fridays 16 and 23 Oct) | Ettore | Dated notes in `status/` | 6 | Fri 16 Oct | Fri 23 Oct | 1.6 | After each meeting, real dates, status changes, and incidents are recorded. |
| 1.8 | Prepare the Project Status document for the 22 Oct discussion | Ettore | Updated `status/` document | 1 | Tue 20 Oct | Tue 20 Oct | 1.6 | Planned and real dates, status, and notes are current on 20 Oct. |
| 1.9 | Produce the final Gantt chart with real dates (live version) | Ettore | Final Gantt chart in `gantt/` | 1 | Tue 27 Oct | Tue 27 Oct | 4.6 | Every task shows its real dates, and deviations are explained. |

### WP2 — Data sources, literature, and sequences

Tue 13 Oct – Mon 19 Oct (5 working days)

| ID | Task | Owner | Output | Days | Start | End | Predecessors | Accomplished when |
|---|---|---|---|---|---|---|---|---|
| 2.1 | Characterize the supplied sequences: translate both CDSs, compare wild type and mutant, and name the variant in HGVS nomenclature | Leo | Variant table (DNA and protein level) | 1 | Tue 13 Oct | Tue 13 Oct | 1.3 | Every difference is listed at DNA and protein level and verified by a second member (task 2.8). |
| 2.2 | Identify the gene, the isoform, and the reference entries (HGNC, NCBI Gene, UniProt) | Bruno | Table of identifiers | 1 | Tue 13 Oct | Tue 13 Oct | 1.5 | The gene symbol, isoform, and accession numbers are recorded with access dates. |
| 2.3 | Collect clinical and population evidence on the variant (ClinVar, gnomAD, OMIM, literature) | Bruno | Evidence table with sources | 2 | Thu 15 Oct | Fri 16 Oct | 2.1, 2.5 | Classification, allele frequency, and published functional data are recorded with sources. |
| 2.4 | Review the literature on PK and PKD: normal function, mechanism, inheritance, and clinical features | Aarón | Annotated literature notes | 3 | Tue 13 Oct | Thu 15 Oct | 1.2 | Each statement planned for the Background has at least one primary or review source. |
| 2.5 | Retrieve the reviewed orthologous sequences: rat, mouse, and dog (outgroup) | Bruno | FASTA files and accession list | 1 | Wed 14 Oct | Wed 14 Oct | 2.2 | Every sequence is saved in the repository with its accession number. |
| 2.6 | Select the experimental structures: wild-type and mutant human R-type PK; rat PK | Pol | Table of PDB entries (method, resolution, construct) | 1 | Tue 13 Oct | Tue 13 Oct | 1.4 | One wild-type and one mutant entry are chosen, with the reasons recorded. |
| 2.7 | Archive the sources in `references/` and maintain the reference list | Bruno | PDFs and Mini Oxford reference list | 1 | Mon 19 Oct | Mon 19 Oct | 2.3, 2.4 | Every cited source is archived and listed in the required style. |
| 2.8 | Verify the sequence characterization independently: repeat the translation and the comparison of the four files | Ettore | Verification note | 1 | Wed 14 Oct | Wed 14 Oct | 2.1 | The variant table of task 2.1 is confirmed, or each discrepancy is resolved with its owner. |

### WP3 — Sequence and structure analysis

Wed 14 Oct – Wed 21 Oct (6 working days)

| ID | Task | Owner | Output | Days | Start | End | Predecessors | Accomplished when |
|---|---|---|---|---|---|---|---|---|
| 3.1 | Pairwise alignments of human PK with the rat and mouse orthologs (protein and CDS) | Leo | Alignments and identity table | 1 | Thu 15 Oct | Thu 15 Oct | 2.1, 2.5 | Percent identity and similarity are reported for each pair, with tool and parameters. |
| 3.2 | Multiple sequence alignment of human, rat, mouse, and dog PK; conservation of the substituted position and lineage of each difference | Leo | Alignment figure and conservation notes | 2 | Fri 16 Oct | Mon 19 Oct | 3.1 | The residue at the substituted position is reported for every species, and the lineage of each change is stated. |
| 3.3 | Map the substituted residue on the wild-type structure: distances to the active site, the allosteric site, and the domain and subunit interfaces | Pol | Annotated structure figure and distance table | 2 | Wed 14 Oct | Thu 15 Oct | 2.1, 2.6 | Distances are measured in a stated structure and chain. |
| 3.4 | Superpose the wild-type and mutant structures (repeated in the 22 Oct lab) | Pol | Superposition figure and RMSD values | 2 | Fri 16 Oct | Mon 19 Oct | 3.3 | Global and local differences are quantified with the method stated. |
| 3.5 | Compare the human R-type and rat L-type structures around the substituted position | Pol | Comparison figure and notes | 1 | Tue 20 Oct | Tue 20 Oct | 3.4, 3.2 | The local environment of the position is described in both species. |
| 3.6 | Assess pathogenicity: combine clinical, population, conservation, structural, and biochemical evidence | Aarón | Evidence summary table | 1 | Mon 19 Oct | Mon 19 Oct | 2.3, 2.4, 3.1 | Each line of evidence is classified as measured result, hypothesis, or open question. |
| 3.7 | Explain the impact on the patient: from enzyme activity to red-cell ATP, haemolysis, and clinical severity | Aarón | One-page causal summary | 1 | Tue 20 Oct | Tue 20 Oct | 3.6 | Each step from variant to clinical picture is supported by a cited source or our own result. |
| 3.8 | Team synthesis meeting: from variant to patient | Ettore | Meeting notes | 1 | Wed 21 Oct | Wed 21 Oct | 3.5, 3.7, 3.9 | Every member can explain the full chain from variant to patient. |
| 3.9 | Verify the alignments independently: repeat the multiple sequence alignment and check the residue at the substituted position in every species | Bruno | Verification note | 1 | Tue 20 Oct | Tue 20 Oct | 3.2 | The residues reported in task 3.2 are confirmed, or each discrepancy is resolved with its owner. |

### WP4 — Report, delivery, and defence

Tue 20 Oct – Tue 3 Nov (11 working days)

| ID | Task | Owner | Output | Days | Start | End | Predecessors | Accomplished when |
|---|---|---|---|---|---|---|---|---|
| 4.1 | Write the Background | Aarón | Background section in `report/` | 2 | Wed 21 Oct | Thu 22 Oct | 2.4 | It states the problem and the question, with every claim cited. |
| 4.2 | Write the Methods | Bruno | Methods section in `report/` | 2 | Wed 21 Oct | Thu 22 Oct | 2.7, 3.9 | Another student could reproduce every analysis from it. |
| 4.3 | Write the Results on sequences and species comparison | Leo | Results, part 1 | 2 | Tue 20 Oct | Wed 21 Oct | 3.2 | It reports what was measured, without interpretation, with numbered figures or tables. |
| 4.4 | Write the Results on structures; prepare the figures | Pol | Results, part 2; figures | 2 | Wed 21 Oct | Thu 22 Oct | 3.5 | Figures are numbered, captioned, and stored in the repository. |
| 4.5 | Write the Discussion and Conclusions | Ettore | Discussion and Conclusions | 2 | Thu 22 Oct | Fri 23 Oct | 3.8 | They answer the project question and state the limitations. |
| 4.6 | Write the Abstract and assemble the report | Aarón | Complete report | 1 | Mon 26 Oct | Mon 26 Oct | 4.1, 4.2, 4.3, 4.4, 4.5 | All BMC sections are present; the Abstract has at most 350 words. |
| 4.7 | Coordinate the full read-through and corrections | Leo | Corrected report | 1 | Tue 27 Oct | Tue 27 Oct | 4.6 | Every member has read the whole report and all comments are resolved. |
| 4.8 | Check the format limits and the references | Bruno | Completed checklist | 1 | Tue 27 Oct | Tue 27 Oct | 4.6 | At most 7 pages or 5 000 words and five figures or tables; references in Mini Oxford style. |
| 4.9 | Deliver the final report on GitHub | Aarón | Final repository | 1 | Wed 28 Oct | Wed 28 Oct | 4.7, 4.8, 1.9 | All files are committed by 12:00 on 28 Oct, six hours before the 18:00 deadline. |
| 4.10 | Prepare the defence slides on the background and the impact on the patient | Aarón | Slides, part 1 | 1 | Thu 29 Oct | Thu 29 Oct | 4.9 | The slides cover the Background and SO3, and their presenter is named. |
| 4.11 | Prepare the defence slides on the data sources and methods | Bruno | Slides, part 2 | 1 | Thu 29 Oct | Thu 29 Oct | 4.9 | The slides cover the Methods, and their presenter is named. |
| 4.12 | Prepare the defence slides on the discussion and conclusions | Ettore | Slides, part 3 | 1 | Thu 29 Oct | Thu 29 Oct | 4.9 | The slides answer the project question and state the limitations. |
| 4.13 | Prepare the defence slides on the sequence and species-comparison results | Leo | Slides, part 4 | 1 | Thu 29 Oct | Thu 29 Oct | 4.9 | The slides cover SO1 and SO4 results, and their presenter is named. |
| 4.14 | Prepare the defence slides on the structural results | Pol | Slides, part 5 | 1 | Thu 29 Oct | Thu 29 Oct | 4.9 | The slides cover SO2 results, and their presenter is named. |
| 4.15 | Assemble the defence presentation: unify the format and confirm who presents each part | Bruno | Complete presentation | 1 | Fri 30 Oct | Fri 30 Oct | 4.10, 4.11, 4.12, 4.13, 4.14 | One presentation in a single format, with every member presenting a part. |
| 4.16 | Coordinate the defence rehearsal, with cross-questioning between members | Leo | Rehearsal and list of likely questions | 2 | Mon 2 Nov | Tue 3 Nov | 4.15 | Every member can answer questions on every part of the project. |

---
[← 2. Gantt chart](PKD_3_Gantt_Chart.md) · [Index](README.md) · [3. Risk analysis →](PKD_5_Risk_Analysis.md)
