# Project Status

Live Project Status document (Disease Project Formal Requirements, section III), created on 13 October (task 1.6) and updated at each weekly meeting (task 1.7). Until then, task tracking is in the *Tasks* sheet of [`../gantt/Gantt_live_11DP-C.xlsx`](../gantt/Gantt_live_11DP-C.xlsx).
