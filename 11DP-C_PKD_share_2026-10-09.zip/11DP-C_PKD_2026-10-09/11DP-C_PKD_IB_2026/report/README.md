# Report

Main project report in the *BMC Bioinformatics* format (Disease Project Formal Requirements, section II.1). Written from 21 October (tasks 4.1 to 4.6, see [`../gantt/PKD_4_Task_Details.md`](../gantt/PKD_4_Task_Details.md)).
