# Group 11DP-C · project plan of 9 October 2026

What is in this folder:

| Item | What it is | Commit it? |
|---|---|---|
| `reading_versions/11DP-C_PKD_project_plan.pdf` | The whole plan in one document: the easiest way to read it | No |
| `reading_versions/11DP-C_PKD_project_plan.html` | The same, as a single web page (open it in any browser) | No |
| `COMMIT_PLAN_2026-10-09.md` | Who reviews and commits which section tomorrow, in which order, before 18:00 | No |
| `11DP-C_PKD_IB_2026/` | The files to add to our GitHub repository tomorrow, in the repository's folder structure | **Yes**, following the commit plan |

Before committing your section: read it, and write your own background in the team section (`gantt/PKD_2_Overview_and_Team.md`, under your name). Commit from your own GitHub account; only human commits are assessed.

If you change a file, tell Ettore, so that a single version of the plan exists.
