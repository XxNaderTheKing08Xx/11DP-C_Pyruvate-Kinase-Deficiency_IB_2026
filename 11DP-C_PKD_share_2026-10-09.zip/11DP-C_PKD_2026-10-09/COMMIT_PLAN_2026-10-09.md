# Commit plan · Friday 9 October 2026

*Working note for Group 11DP-C. Not to be committed.* Tasks 1.1 to 1.5 of the plan. Each member reads the section they commit before committing it, and commits it from their own GitHub account (only human commits are assessed: Use of GenAI in IB). Commit in this order, since 1.1 creates the folders the others use. Deadline: 18:00 (Overview).

Repository: https://github.com/XxNaderTheKing08Xx/11DP-C_Pyruvate-Kinase-Deficiency_IB_2026

| Order | Task | Member | Files (from `11DP-C_PKD_IB_2026/`) | Suggested commit message |
|---|---|---|---|---|
| 1 | 1.1 | Ettore Colombo | `report/README.md`, `status/README.md`, `references/README.md`, `references/Valentini_2002_JBiolChem.pdf`, `gantt/README.md`, `gantt/PKD_1_Introduction.md` | Create required folders; add plan index and introduction (task 1.1) |
| 2 | 1.2 | Aarón Godino Martínez | `gantt/PKD_2_Overview_and_Team.md` | Add project overview, objectives, milestones, and team (task 1.2) |
| 3 | 1.3 | Leo Nader Al Hourani | `gantt/PKD_3_Gantt_Chart.md`, `gantt/gantt_chart_2026-10-09.png` | Add Gantt chart of 9 October (task 1.3) |
| 4 | 1.4 | Pol Monllau | `gantt/PKD_4_Task_Details.md`, `gantt/Gantt_live_11DP-C.xlsx` | Add task details and live Gantt workbook (task 1.4) |
| 5 | 1.5 | Bruno Carrasquilla | `gantt/PKD_5_Risk_Analysis.md`, `gantt/PKD_6_References.md` | Add risk analysis and references (task 1.5) |
| 6 | 1.2 | Aarón Godino Martínez | — | Submit on Moodle the URL of the plan: `…/tree/main/gantt` |

## Checks before submitting the URL

1. The chart image appears in `gantt/PKD_3_Gantt_Chart.md` on GitHub, and the Mermaid chart opens under "The same plan as a Mermaid chart".
2. The navigation links at the bottom of each section work.
3. The commit history shows five commits, one by each member.
